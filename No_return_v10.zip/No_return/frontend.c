#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
void menu()
{
    int selection = 0;
    int ispress = 0;
    int lenguage = read_config();
    char* option_screen;
    char ch;
    printf("\n\n\n\n\n\n\n\n\n\n");
    header(1);
    printf("\n\n");
    if(lenguage == 0)
    {
        do
        {
            switch(ispress)
            {
            case 0:
                option_screen = "\t\t\t\t\t\t\t\t\t->PLAY   RECORD   OPTIONS";
                selection = 0;
                break;
            case 1:
                option_screen = "\t\t\t\t\t\t\t\t\t  PLAY ->RECORD   OPTIONS";
                selection = 1;
                break;
            case 2:
                option_screen = "\t\t\t\t\t\t\t\t\t  PLAY   RECORD ->OPTIONS";
                selection = 2;
                break;
            default:
                if(selection == 0)
                {
                    ispress = 0;
                }
                else
                {
                    if(selection == 1)
                    {
                        ispress = 1;
                    }
                    else
                    {
                        ispress = 2;
                    }
                }
                break;
            }
            printf("\r%s",option_screen);
            ch = getch();
            if(ispress == 0 && ch == 75)
            {
                ispress = 0;
            }
            else
            {
                if(ch == 77)
                {
                    ispress++;
                    if(ispress > 2)
                    {
                        ispress = 2;
                    }
                }
                if(ch == 75)
                {
                    ispress--;
                    if(ispress < 0)
                    {
                        ispress = 0;
                    }
                }
            }
        }
        while(ch != 13);
        if(selection == 0)
        {
            clear_screen();
            game_init();
        }
        else
        {
            if(selection == 1)
            {
                clear_screen();
                header(17);
                read_record(0);
                back_menu();
            }
            else
            {
                clear_screen();
                options(0);
            }
        }
    }
    else
    {
        do
        {
            switch(ispress)
            {
            case 0:
                option_screen = "\t\t\t\t\t\t\t\t\t->JOGAR   HISTORICO   OPCOES";
                selection = 0;
                break;
            case 1:
                option_screen = "\t\t\t\t\t\t\t\t\t  JOGAR ->HISTORICO   OPCOES";
                selection = 1;
                break;
            case 2:
                option_screen = "\t\t\t\t\t\t\t\t\t  JOGAR   HISTORICO ->OPCOES";
                selection = 2;
                break;
            default:
                if(selection == 0)
                {
                    ispress = 0;
                }
                else
                {
                    if(selection == 1)
                    {
                        ispress = 1;
                    }
                    else
                    {
                        ispress = 2;
                    }

                }
                break;
            }
            printf("\r%s",option_screen);
            ch = getch();
            if(ispress == 0 && ch == 75)
            {
                ispress = 0;
            }
            else
            {
                if(ch == 77)
                {
                    ispress++;
                    if(ispress > 2)
                    {
                        ispress = 2;
                    }
                }
                if(ch == 75)
                {
                    ispress--;
                    if(ispress < 0)
                    {
                        ispress = 0;
                    }
                }
            }
        }
        while(ch != 13);
        if(selection == 0)
        {
            clear_screen();
            inicio_jogo();
        }
        else
        {
            if(selection == 1)
            {
                clear_screen();
                header(18);
                read_record(1);
                back_menu();

            }
            else
            {
                clear_screen();
                options(1);
            }
        }
    }

}

void options(int leng)
{


    int selection = 0;
    int ispress = 0;
    char* options;
    char ch;

    if(leng == 0)
    {
        header(2);
        printf("\n\n");
        do
        {
            switch(ispress)
            {
            case 0:
                options = "Language: English   ";
                selection = 0;
                break;
            case 1:
                options = "Language: Portuguese";
                selection = 1;
                break;
            default:
                if(selection == 0)
                {
                    ispress = 0;
                }
                else
                {
                    ispress = 1;
                }
                break;
            }
            printf("\r%s",options);
            ch = getch();
            if(ispress == 0 && ch == 75)
            {
                ispress = 0;
            }
            else
            {
                if(ch == 77)
                {
                    ispress++;
                    if(ispress > 1)
                    {
                        ispress = 1;
                    }
                }
                if(ch == 75)
                {
                    ispress--;
                    if(ispress < 0)
                    {
                        ispress = 0;
                    }
                }
            }
        }
        while(ch != 13);

        if(selection == 0)
        {
            lenguage_option(options);
        }
        else
        {
            lenguage_option(options);
        }

    }
    else
    {
        header(3);
        printf("\n\n");
        do
        {
            switch(ispress)
            {
            case 0:
                options = "Idioma: Ingles   ";
                selection = 0;
                break;
            case 1:
                options = "Idioma: Portugues";
                selection = 1;
                break;
            default:
                if(selection == 0)
                {
                    ispress = 0;
                }
                else
                {
                    ispress = 1;
                }
                break;
            }
            printf("\r%s",options);
            ch = getch();
            if(ispress == 0 && ch == 75)
            {
                ispress = 0;
            }
            else
            {
                if(ch == 77)
                {
                    ispress++;
                    if(ispress > 1)
                    {
                        ispress = 1;
                    }
                }
                if(ch == 75)
                {
                    ispress--;
                    if(ispress < 0)
                    {
                        ispress = 0;
                    }
                }
            }
        }
        while(ch != 13);

        if(selection == 0)
        {
            lenguage_option(options);
        }
        else
        {
            lenguage_option(options);
        }
    }
    back_menu();
}
void clear_screen()
{
    system("cls");
}
void back_menu()
{
    char ch;

    printf("\n\nPress esc to return\n");
    ch = getch();
    if(ch == 27)
    {
        clear_screen();
        menu();
    }
}
void header(int opcao)
{
    switch(opcao)
    {
    case 1:
        printf("\t\t\t\t\t\t       _   _   ____    _____    _____   _____   _    _  _____   _    _\n");
        printf("\t\t\t\t\t\t      | \\ | | | __ |  |  _  |  | ____| |__ __| | | | | |  _  |  | \\ | |\n");
        printf("\t\t\t\t\t\t      |  \\| | ||  ||  | |_|/   |  _|     | |   | | | | | |_|/   |  \\| |\n");
        printf("\t\t\t\t\t\t      | |\\  | ||__||  | | \\    | |__     | |   | |_| | | | \\    |  \\  |\n");
        printf("\t\t\t\t\t\t      |_| \\_| |____|  |_|  \\_  |_____|   |_|   |_____| |_|  \\_  |_| \\_|\n");
        printf("\t\t\t\t\t\t                                                     \n");
        break;
    case 2:
        printf("\t\t\t\t\t\t\t  ____    _____  _____   _    ____   _    _   ______ \n");
        printf("\t\t\t\t\t\t\t | __ |  |     ||__ __| | |  | __ | | \\ | | |  ____|\n");
        printf("\t\t\t\t\t\t\t ||  ||  |  ___|  | |   | |  ||  || |  \\| | |____  |\n");
        printf("\t\t\t\t\t\t\t ||__||  | |      | |   | |  ||__|| |  \\  |  ____| |\n");
        printf("\t\t\t\t\t\t\t |____|  |_|      |_|   |_|  |____| |_| \\_| |______|\n");
        printf("\t\t\t\t\t\t\t                                                     \n");
        break;
    case 3:
        printf("\t\t\t\t\t\t\t  ____    _____   ____   ____   _____    ______\n");
        printf("\t\t\t\t\t\t\t | __ |  |     | |  __| | __ | | ____| |  ____|\n");
        printf("\t\t\t\t\t\t\t ||  ||  |  ___| | |    ||  || |  _|   |____  |\n");
        printf("\t\t\t\t\t\t\t ||__||  | |     | |__  ||__|| | |__    ____| |\n");
        printf("\t\t\t\t\t\t\t |____|  |_|     |____| |____| |_____| |______|\n");
        printf("\t\t\t\t\t\t\t                                               \n");
        break;
    case 4:
        printf("\t\t\t                               ____      ____   ____   __  __   ______   \n");
        printf("\t\t\t                              |  _ \\   | __ | | __ | |  \\/  | | ____  |  \n");
        printf("\t\t\t                              | |_) |  ||  |  ||  || | |\\/| | | |____ \n");
        printf("\t\t\t                              |  _ <   ||__|| ||__|| | |  | |   ____| |\n");
        printf("\t\t\t                              |_| \\_\\  |____| |____| |_|  |_| |_______|  \n");
        printf("\t\t\t                                                                     \n");
        break;
    case 5:
        printf("\t\t\t\t\t\t\t__        __                                \n");
        printf("\t\t\t\t\t\t\t\\ \\      / /__  __ _ _ __   ___  _ __  ___  \n");
        printf("\t\t\t\t\t\t\t \\ \\ /\\ / / _ \\/ _` | '_ \\ / _ \\| '_ \\/ __| \n");
        printf("\t\t\t\t\t\t\t  \\ V  V /  __/ (_| | |_) | (_) | | | \\__ \\ \n ");
        printf("\t\t\t\t\t\t\t   \\_/\\_/ \\___|\\__,_| .__/ \\___/|_| |_|___/ \n");
        printf("\t\t\t\t\t\t\t                    |_|                    \n");
        printf("\t\t\t\t\t\t\t                                          \n\n");
        break;
    case 6:
        printf("\t\t\t\t\t\t\t _                   _   _   _       \n");
        printf("\t\t\t\t\t\t\t| |    _____   _____| | | | | |_ __  \n");
        printf("\t\t\t\t\t\t\t| |   / _ \\ \\ / / _ \\ | | | | | '_ \\\n");
        printf("\t\t\t\t\t\t\t| |__|  __/\\ V /  __/ | | |_| | |_) |\n");
        printf("\t\t\t\t\t\t\t|_____\\___| \\_/ \\___|_|  \\___/| .__/\n");
        printf("\t\t\t\t\t\t\t                              |_|    \n");
        break;
    case 7:
        printf("  ____                         ___                 \n");
        printf(" / ___| __ _ _ __ ___   ___   / _ \\__   _____ _ __ \n");
        printf("| |  _ / _` | '_ ` _ \\ / _ \\ | | | \\ \\ / / _ \\ '__|\n");
        printf("| |_| | (_| | | | | | |  __/ | |_| |\ V /  __/ |   \n");
        printf(" \\____|\\__,_|_| |_| |_|\\___|  \\___/ \\_/ \\___|_|   \n");
        break;
    case 8:
        printf(" _____ _                 _            _                   \n");
        printf("|  ___(_)_ __ ___     __| | ___      | | ___   __ _  ___  \n");
        printf("| |_  | | '_ ` _ \\   / _` |/ _ \\  _  | |/ _ \\ / _` |/ _ \\ \n");
        printf("|  _| | | | | | | | | (_| |  __/ | |_| | (_) | (_| | (_) |\n");
        printf("|_|   |_|_| |_| |_|  \\__,_|\\___|  \\___/ \\___/ \\__, |\\___/ \n");
        printf("                                              |___/       \n");
        break;
    case 9:
        printf("\t\t\t _   _            _ \n");
        printf("\t\t\t| | | | ___  __ _| |\n");
        printf("\t\t\t| |_| |/ _ \\/ _` | |\n");
        printf("\t\t\t|  _  |  __/ (_| | |\n");
        printf("\t\t\t|_| |_|\\___|\\__,_|_|\n");
        break;
    case 10:
        printf("\t\t\t  ____                \n");
        printf("\t\t\t / ___|   _ _ __ __ _ \n");
        printf("\t\t\t| |  | | | | '__/ _` |\n");
        printf("\t\t\t| |__| |_| | | | (_| |\n");
        printf("\t\t\t \\____\\__,_|_|  \\__,_|\n");
        break;
    case 11:
        printf("\t\t\t ____  _                 \n");
        printf("\t\t\t/ ___|| |__   ___  _ __  \n");
        printf("\t\t\t\\___  \| '_ \\ / _ \\| '_ \\ \n");
        printf("\t\t\t ___) | | | | (_) | |_) |\n");
        printf("\t\t\t|____/|_| |_|\\___/| .__/ \n");
        printf("\t\t\t                  |_|   \n");
        break;
    case 12:
        printf("\t\t\t _          _       \n");
        printf("\t\t\t| |    ___ (_) __ _ \n");
        printf("\t\t\t| |   / _ \\| |/ _` |\n");
        printf("\t\t\t| |__| (_) | | (_| |\n");
        printf("\t\t\t|_____\\___// |\\__,_|\n");
        printf("\t\t\t         |__/    \n");
        break;
    case 13:
        printf("\t\t\t                      _       \n");
        printf("\t\t\t  _____   _____ _ __ | |_ ___ \n");
        printf("\t\t\t / _ \\ \\ / / _ \\ '_ \\| __/ __|\n");
        printf("\t\t\t|  __/\\ V /  __/ | | | |_\\__ \\\n");
        printf("\t\t\t \\___| \\\_/ \\___|_| |_|\\__|___/\n");
        break;
    case 14:
        printf("\t\t\t                      _            \n");
        printf("\t\t\t  _____   _____ _ __ | |_ ___  ___ \n");
        printf("\t\t\t / _ \\ \\ / / _ \\ '_ \\| __/ _ \\/ __|\n");
        printf("\t\t\t|  __/\\ V /  __/ | | | || (_) \\__ \\\n");
        printf("\t\t\t \\___| \\_/ \\___|_| |_|\\__\\___/|___/\n");
        break;
    case 15:
        printf("\t\t\t ____                \n");
        printf("\t\t\t| __ )  ___  ___ ___ \n");
        printf("\t\t\t|  _ \\ / _ \\/ __/ __|\n");
        printf("\t\t\t| |_) | (_) \\__ \\__ \\\n");
        printf("\t\t\t|____/ \\___/|___/___/\n\n");
        break;
    case 16:
        printf("\t\t\t  ____ _           __      \n");
        printf("\t\t\t / ___| |__   ___ / _| ___ \n");
        printf("\t\t\t| |   | '_ \\ / _ \\ |_ / _ \\\n");
        printf("\t\t\t| |___| | | |  __/  _|  __/\n");
        printf("\t\t\t \\____|_| |_|\\___|_|  \\___|\n");
        break;
    case 17:
        printf("\t\t\t ____                        _     \n");
        printf("\t\t\t|  _ \\ ___  ___ ___  _ __ __| |___ \n");
        printf("\t\t\t| |_) / _ \\/ __/ _ \\| '__/ _` / __|\n");
        printf("\t\t\t|  _ <  __/ (_| (_) | | | (_| \\__ \\\n");
        printf("\t\t\t|_| \\_\\___|\\___\\___/|_|  \\__,_|___/\n\n\n");
        break;
    case 18:
        printf("\t\t\t _   _ _     _             _           \n");
        printf("\t\t\t| | | (_)___| |_ ___  _ __(_) ___ ___  \n");
        printf("\t\t\t| |_| | / __| __/ _ \\| '__| |/ __/ _ \\ \n");
        printf("\t\t\t|  _  | \\__ \\ || (_) | |  | | (_| (_) |\n");
        printf("\t\t\t|_| |_|_|___/\\__\\___/|_|  |_|\\___\\___/ \n\n\n");
        break;
    }
}

void sprites(int opcao)
{
    int num_linhas;
    int i;
    switch(opcao)
    {
    case 1:
        ;
        char *slime[] =
        {
            "\t\t                   ##########%%%%%%",
            "\t\t                   @@******#####%@@",
            "\t\t                  @*************##%@",
            "\t\t                @---=+*************#%@@",
            "\t\t              @**+===+*********++*****#%%@",
            "\t\t            @****************************%@",
            "\t\t           @***==*************************%%@",
            "\t\t          @=+************+++***************#%@@",
            "\t\t         @%%%*****######*++*#########*******#%%@",
            "\t\t        @%#****###############%#%%%%%%%%%%%%#**#%@",
            "\t\t       @%%##################%%%%%%%%%###%%%%%%%%%%%",
            "\t\t      @@%%##############%%%%%%%%%%%%%%##%%%%%%%%%%%",
            "\t\t      @@%%##############%##%%%%%%%%%%%%%%%%%%%%%%%%",
            "\t\t      @@@@@%#############%%%%%%%%%%%%%%%##%%%%%%%%@@@",
            "\t\t      @@@@@@@%##########%%%%%%%%%%%%%%%%%%%%%%%%@@@@@",
            "\t\t        @@@@@@%%#########%%%%%%%%%%%%%%%%%%%%%%@@@@@@",
            "\t\t          @@@@@@%%%%%#%%#%%%%%%%%%%%%%%@@@@@@@@@",
            "\t\t             @@@@@%%%%%%%%%%%%%@@@@@@@@@@@",
        };

        num_linhas = sizeof(slime) / sizeof(slime[0]);

        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", slime[i]);
        }
        break;
    case 2:
        ;
        char *skeleton[] =
        {
            "\t\t          ..     .     ..",
            "\t\t             .#%#=%%%+  ",
            "\t\t            :*%%+#%%= .:",
            "\t\t            *#%**%%%#***",
            "\t\t            *-----:=#:-",
            "\t\t            -#+++*#- -",
            "\t\t          =   :=::--.=*#*### ",
            "\t\t          -===-+-*.+=******#*",
            "\t\t          :-===++%--*+==***=-",
            "\t\t      *++++ *-====+*##***+:.",
            "\t\t   ++***=+**+=::===+#**##%  .:",
            "\t\t  +*+=-----==*.-#====*%%#% -.:",
            "\t\t +*=----=++*-. +#%+=-=+%%# .:",
            "\t\t +*-----=#-*=:=++@#::.-=+#-.-",
            "\t\t **-:=..:+*=*=+*#@@*++*=+:..",
            "\t\t +++---=-----=**-*@@@#=--:+=",
            "\t\t  +**==-----+*+++=****-+#=",
            "\t\t   ++***=***++  .***+##..",
            "\t\t      ++*+++ ##+ +%#%# *:- ",
            "\t\t             ###++    ####*",
            "\t\t            %####%@   %###%@",
            "\t\t            #%%%%%@   #%%%%%",
            "\t\t            #%%%#%    #%%%#%",
            "\t\t             #%%#%    %#%%#%",
            "\t\t            *####*     ####+",
            "\t\t           *######*   *#####*",
            "\t\t           *###*+    +###**",
        };
        num_linhas = sizeof(skeleton) / sizeof(skeleton[0]);

        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", skeleton[i]);
        }
        break;
    case 3:
        ;
        char *goblin[] =
        {
            "\t\t        @@@@@",
            "\t\t        @%% %",
            "\t\t       @%%##%@%%",
            "\t\t      @**=-=**@@",
            "\t\t %#*#@%=======#@#*#%@",
            "\t\t   @%#*+-=+=-+*#%@",
            "\t\t     @%===++==%@",
            "\t\t     @@%#***#%@%%@",
            "\t\t   %%##%%%*=*%%%+=*#@",
            "\t\t  @%*++##%%%%%###%#*#%",
            "\t\t  %#*%%####%##**%@#++%@",
            "\t\t @#==%@%+*#%#**%@ #*=#@",
            "\t\t %*=#%@%%%#*##%%@%+-+%@",
            "\t\t @#=*%%*#**#####%@*+#%",
            "\t\t  #==*@%##%%#**#%@@@",
            "\t\t @%*-+#@##@@%%%%@@",
            "\t\t @%*-=#@%@@ @@@@%@",
            "\t\t  @*:=%*#@@ @%*+*@",
            "\t\t  @*:+%*%@  @@%##@",
            "\t\t   @+%      @@%*#%@",
            "\t\t    @        @@@@@",

        };
        num_linhas = sizeof(goblin) / sizeof(goblin[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", goblin[i]);
        }
        break;
    case 4:
        ;
        char *dragon[] =
        {
            "                  -===++",
            "       -     =-***#:",
            "    -:  **#**.=%%-  .",
            "  .:-##***+#-:+@%####-",
            "      -######++=**#*###*-.",
            "       ====+*=++#*#%%%%%%+",
            "     .=: .:=+.=  =#*++####=",
            "                 +*+*#%#-",
            "                   *####%#",
            "                  -+=#*%=            =* ",
            "                   ##+#*#           =### ",
            "                  -##**#%.        :%%%%#  ",
            "                  =+***#%#.     -%%@#%#%=  ",
            "                 +++*=####%#:  +#+%#*: -*=  =",
            "                .**#*+#%%#%%#*##*%***:- ***#=",
            "                ++++=*###%%##%%#*##*%* *#%##  ",
            "               .+**#+:*%%%%#%##%#*%@#*+*##++  ",
            "              .*+++*####%##*****#**#***+++++:      .  ",
            "                +#***##%%**+++######%*##***#       +   ",
            "            .+**+++**###%%#####*#%#@@%%%@@##+=  .%*##+  ",
            "                .*#***#%%%%***%#%%%@%%%%%%%#*+- :-#%*.  ",
            "                  ++##########%%%%%%##%####*###*#%#%=  ",
            "                   #**######+  *%#%*#+#%#*#%%%%%%#. ",
            "                  :%#%%#-      +##%%@= =%%@@%%+  ",
            "                  *%%@%+       +%@%##*  :%##### ",
            "                -#%%%%%=       .##*##*  +#%%#%# ",
            "              .=*#%%%%-        -###%%# :+*%*##%-  ",
            "                             :######%#.    .. ",
            "                            :=*%##%#%% ",
            "                             ..=+=*:",
        };
        num_linhas = sizeof(dragon) / sizeof(dragon[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", dragon[i]);
        }
        break;
    case 5:
        ;
        char *orc[]=
        {
            "                     #%@@@@@@:",
            "                      *@@@+++++:",
            "                     +*#@#+*****.",
            "                      =**+*#**#%.",
            "                      *%*++**++*.",
            "                     =#%%**+-.-*.",
            "                   =*%%%%*+******=",
            "                 .%%%%%%%%#++*#%%%%:",
            "                 .#%%%%%%%%%#%%%%%%=",
            "        :--      .-+*#%%%%%%%%%%%%%#*=",
            "         .*+:    -+++*%%%%%%%%%%%%%++=",
            "          -+-.   =++*#%%%%%%%%%%%%%++++.",
            "             *..=+++=+%%%%%%%%%%%%%:=++.",
            "               +++=  .%%%%%%%%%%%%# -++.",
            "               =++-   ++**####%@@@# -++.",
            "                +*-  .%%%@@@@@@@@@# -+:",
            "                 *+. .#%%%%%%%%%%%#",
            "                  =%+++*#%%%%%%%%%#",
            "                    -.##+**#%%%%%%#",
            "                     .%%#= .==#%%%#",
            "                     .#@@+.   -#%%#",
            "                     .##%=-   .=*#+",
            "                     .###**+-   *#+",
            "                    :=##+..-=-  *#*=",
            "                  .*%%%%+     :=%%%@#+",
        };
        num_linhas = sizeof(orc) / sizeof(orc[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", orc[i]);
        }
        break;
    case 6:
        ;
        char *gnoll[] =
        {
            "                @@. *",
            "             *@@@@@@@@@@@%@@*",
            "            #: *@ .:#@   @@@@",
            "           +@@%@@@@+%@@@@@@%@@*",
            "             @@@@@@@@@+@@@@@@#@",
            "              #@@@@@@@@@@@@@@@@@@",
            "                @@@@@@@@@@@@@@@@@@@:",
            "                 @@@@@@@@@@@@.*@@@@",
            "                  @@*  #@@@@@. @@@@@",
            "                 .@@@=%@@#@@@   @@@",
            "                 %@@@@@@@@@@@@=   @@@",
            "                @@@@@@@@@@@@@@  @@@@@",
            "           @@@@@@@@@@@@@@@@@@@@  @@@",
            "    *@@@@@@@+  @@@@@ *@@@@@@   =@@@@",
            "  @@@@@@         @@  @@@@@@@",
            "   @@@          @@     %@@+@@@",
            "              @@@@          @@",
            "              +@%:         @@@",
            "                          %@@@.",
            "                          @@@@@##",
        };
        num_linhas = sizeof(gnoll) / sizeof(gnoll[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", gnoll[i]);
        }
        break;
    case 7:
        ;
        char *demon[] =
        {
            "                                   @@@@      @@@@@",
            "                                @@@**@    @@@@%@@",
            "                               @***@     @##@@@",
            "                            @#**#*@    @@%#@@@",
            "                          @%**###*@   @#%@@@@@%@@",
            "                         @#*######%@@@@%*+#%@@%@@@",
            "                        @#*######@*@@@+*@@#*#***#@@@",
            "                       @#*#######@**@@@#@@@%#*****#@",
            "                       @*#########@**@@@@@@**@@@#*#@",
            "                      @@*####@@  @@@#*#@@@@@##*@**@",
            "                      @*##%@@    @@@%#***@#*%%###@@",
            "                      @*#%@@    @@%@@@**%****%%@@%@",
            "                      @*#@@     @%##@@@@%***%**###@",
            "                      @*%@      @##%@@ @@%**%***%#@",
            "                      @*@@      @#@@   @##%**@#**@",
            "                      @*@       @#@     @@##**@*@@@@     @",
            "                      @@@       @@     @@@@%@**+@+.@-@@@@ *@@@",
            "                      @        @       @@  *@**@+ :.          :@@",
            "                                    @##%@+%%@@%%@=:#-#%#% -#%@@",
            "                                    @%*#%%@@ @@@@@+@@    @@",
            "                                    @##@@@@  @@%#@@@@",
            "                                    @*++@+@    @@@@+@@",
        };
        num_linhas = sizeof(demon) / sizeof(demon[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", demon[i]);
        }
        break;
    case 8:
        ;
        char *golem[] =
        {
            "                      @@@@",
            "                    @#=#@@",
            "                   @%-.+%@",
            "                   @+..+%+@",
            "                 @@*=--**+#@",
            "         @@@#++*##-:%*--##:=%@@@@@@",
            "        @%###*=::=%#-+===-%@#=-:-*@",
            "        @@@@%#%%%#*@%++=*@@#+-+#%%%@@",
            "        @@+:*@@@@@%%@#**%@%+#%%@%%%@@@",
            "        @@**%@@%+-.:*@++@*--*@@@%#=#@",
            "        @%*-#@ @@%#*#@%%%+--+#@@%+.+%",
            "        @#+*%@%@@@@@@#**%%%%%@  @@#%@",
            "         @@%*-%@%*+#@+:+%@#*%@@ @@@#%@",
            "          @#++@@@@*+@@@@%%--*@  @+=*@@",
            "                %+:=%%@@#+#:+@@ @%==%@",
            "               @%--#*%@@%*%#*@@@@@%%@",
            "               @%*#@@@ @@#==+#%*-=#@",
            "               @%*%*%@  @@%=+@@#.=#@",
            "              @%==-*#@@ @@@%#%@@@@",
            "               @#=+%@@  @@=+:+*@@",
            "             @@%*#%@@",
            "             @*=--=#@@",
            "              @@##@@",
        };
        num_linhas = sizeof(golem) / sizeof(golem[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", golem[i]);
        }
        break;
    case 9:
        ;
        char *espada[] =
        {
            "                          --# . ",
            "                        -++-#..",
            "                      -##+-#.",
            "                    .##+#-+.",
            "                  .##- #+#.",
            "                 .+#- .++#.",
            "                .+#- .-+#.",
            "               -#+..--++",
            "             .-..--++",
            "            .-- -+++",
            "           ###--+++-",
            "   -#+##-+#+.-++#.",
            "     -####  #-##",
            "    -######++-",
            "     +#######+",
            "    ####-#-#++#",
            "  .##-      #+",
            "###+ ",
            "##+ ",
        };
        num_linhas = sizeof(espada) / sizeof(espada[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", espada[i]);
        }
        break;
    case 10:
        ;
        char *katana[] =
        {
            "                          @",
            "                       @-=@",
            "                      @=..#",
            "                     @+: *",
            "                    @#: +",
            "                   @%: =",
            "                  @@: -@",
            "                 @- :%",
            "                @=.:#",
            "               @=..#",
            "              @+: *",
            "             @#: +",
            "           @%: =",
            "         @@: -@",
            "      @@@@-.:%",
            "        @@@%%",
            "      @@@#@@@",
            "    @@#@%   @@",
            "  @@@*%",
            "@@%@%",
            "@%%@",
        };
        num_linhas = sizeof(katana) / sizeof(katana[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", katana[i]);
        }
        break;
    case 11:
        ;
        char *foice[] =
        {
            "                                   .-.",
            "                                  :%%*#@",
            "                                 *#+=*=+.",
            "                               :###*:.::=",
            "                              -++-+%*::::-+",
            "                             =*%:   %*-:::*",
            "                           -*+-     -%*:::* ",
            "                         .*==.       ##:.-= ",
            "                        %=+         :@*::*  ",
            "                      .#=+          -#=:+.  ",
            "                     %=@            -#==- ",
            "                   +=*:            :#**-",
            "                 ++#.            =#@+",
            "                *%*.  ",
            "              :+#-  ",
            "            =%*-  ",
            "           -#*  ",
            "         -++- ",
            "      .+++.",
            "       .+++.",
        };
        num_linhas = sizeof(foice) / sizeof(foice[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", foice[i]);
        }
        break;
    case 12:
        ;
        char *bear[] =
        {
            "         _,-\"\"`\"\"-~`)",
            "       (`~_,=========\"",
            "        |---,___.-.__,\"",
            "        |        o     \\ ___  _,,,,_     _.--.",
            "         \\      `^`    /`_.-\"~      \"~-;`     \\",
            "          \\_      _  .'                 `,     |",
            "            |`-                           \'__/ ",
            "           /                      ,_       \\  `'-. ",
            "          /    .-\"\"~~--.            `\"-,   ;_    /\"",
            "         |              \\               \\  | `\"\"`",
            "          \\__.--'`\"-.   / _               |,",
            "                     `\"`  `~~~---..,     |\"",
            "                                    \\ _.-'`-.",
            "                                     \\       \"",
            "                                      '.     /",
            "                                        `\"~`\"",
        };
        num_linhas = sizeof(bear) / sizeof(bear[0]);
        for (i = 0; i < num_linhas; i++)
        {
            printf("%s\n", bear[i]);
        }
        break;
    }
}

