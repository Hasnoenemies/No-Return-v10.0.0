#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main()
{
    ShowWindow( GetConsoleWindow() , SW_MAXIMIZE);
    menu();
    header(18);
    return 0;
}
