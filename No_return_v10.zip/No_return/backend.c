#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <windows.h>
#include <ctype.h>
typedef struct
{
    int max_hp;
    int hp;
    int money;
    int base_damage;
} Player;

typedef struct
{
    char name[50];
} Room;

typedef struct
{
    char name[50];
    int max_hp;
    int hp;
    int base_damage;
} Monster;

typedef struct
{
    char name[50];
    int skill_damage;
} Skill;

//funcao para quando o player for usar uma skill
int use_skill(Player*player,Skill*skill)
{
    return  skill->skill_damage;
}
// Fun��o de ataque do player
int player_attack(const Player* player, int dmg_weapon)
{
    return player -> base_damage + dmg_weapon;
}

// Fun��o de ataque do monstro
int monster_attack(const Monster* monster)
{
    return monster -> base_damage;
}

// Shuffle para as strings(embaralha as strings)
void shuffle(char arr[][50], int n)
{
    if (n > 1)
    {
        int i;
        for (i = 0; i < n - 1; i++)
        {
            int j = i + rand() / (RAND_MAX / (n - i) + 1);
            char temp[50];
            strcpy(temp, arr[j]);
            strcpy(arr[j], arr[i]);
            strcpy(arr[i], temp);
        }
    }
}
/*fun��o de compra na loja no qual o player so podera comprar um item de cada
que esta sendo exibido(em estoque)*/
void shop(Player * player,int *weapon_damage,Skill*skill)
{

    char items[3][50] = {  "Weapon upgrade", "Skill upgrade", "Heal(25%)" };
    char ch;
    int i;
    const number = 250;
    int prices[3];
    bool inshop= true;
    bool bought[3] = { false, false, false};
    for(i = 0; i < 3; i++)
    {
        int random_price = rand() % (number + 1);
        prices[i] = random_price;
    }
    while(inshop)
    {
        header(11);
        printf("\n\n\t\t\t\tMoney:%d\n\n",player -> money);
        printf("\t1 - %s (%d) | 2 - %s (%d)| 3 - %s (%d)\n", items[0],prices[0], items[1],prices[1], items[2],prices[2]);
        printf("\t\t\tPress any key to continue.\n\n");
        ch = getch();
        int choice;

        switch(ch)
        {
        case '1':
            choice = 0;
            break;
        case '2':
            choice = 1;
            break;
        case '3':
            choice = 2;
            break;
        default:
            inshop = !inshop;
            break;
        }
        if(!inshop)
        {
            break;
        }
        if (bought[choice])
        {
            printf("\nYou have already bought %s.\n", items[choice]);
            Sleep(1500);
            clear_screen();
            continue;
        }
        if (player->money >= prices[choice])
        {
            player->money -= prices[choice];
            bought[choice] = true;
            if (choice == 0)
            {
                *weapon_damage += 20;
                printf("You've upgraded your weapon and now it deals %d dmg\n", *weapon_damage);
            }
            else if (choice == 1)
            {
                skill->skill_damage += 80;
                printf("You've upgraded your skill and now it deals %d dmg\n", skill->skill_damage);
            }
            else
            {
                int heal = (player->hp * 0.25);
                player->hp += heal;
                if (player->hp > player->max_hp)
                {
                    player->hp = player->max_hp;
                }
                printf("You have healed %d HP. Current HP: %d\n", heal, player->hp);
            }
        }
        else
        {
            printf("\nYou don't have enough money to buy %s.\n", items[choice]);
        }
        Sleep(2000);
        clear_screen();
    }
}

//cria e define qual sala o jogador escolheu
void rooms(int cont_level,int *weapon_damage,Player* player,Skill*skill,Monster*mob,Monster*elite,Monster*boss,int *qtd_room)
{
    Room room_1 = { "Time chamber" };
    Room room_2 = { "Battle" };
    Room room_3 = { "Heal" };
    Room room_4 = { "Shop" };
    Room room_5 = { "Elite" };
    Room room_6 = { "Event" };
    Room room_7 = { "Boss" };

    char ch;
    char rooms_array[6][50] = { "Time chamber", "Battle", "Elite", "Event", "Battle", "Battle" };


    shuffle(rooms_array, 6);

    if (cont_level == 3)
    {
        printf("\t\t\t\t\t\t\t\t1 - %s | 2 - %s\n", room_3.name, room_4.name);
        ch = getch();

        switch (ch)
        {
        case '1':
            clear_screen();
            (*qtd_room)++;
            heal(player);
            break;
        case '2':
            clear_screen();
            (*qtd_room)++;
            shop(player,weapon_damage,skill);
            break;
        }
        clear_screen();
        header(15);
        printf("\n\n\t\t\t\tPress any key to fight the boss!");
        getch();

    }
    else if (cont_level == 4)
    {

        clear_screen();
        (*qtd_room)++;
        fight(player,skill,*weapon_damage,2,mob,elite,boss,*qtd_room);
    }
    else
    {
        printf("\t\t\t\t\t\t       1 - %s | 2 - %s | 3 - %s\n", rooms_array[0], rooms_array[1], rooms_array[2]);
        ch = getch();

        clear_screen();
        char* selected_room = NULL;
        if (ch == '1')
        {
            selected_room = rooms_array[0];
            (*qtd_room)++;
        }
        else if (ch == '2')
        {
            selected_room = rooms_array[1];
            (*qtd_room)++;
        }
        else if (ch == '3')
        {
            selected_room = rooms_array[2];
            (*qtd_room)++;
        }

        if (strcmp(selected_room, room_1.name) == 0)
        {
            clear_screen();
            time_chamber(player);
        }
        else if (strcmp(selected_room, room_2.name) == 0)
        {
            fight(player,skill,*weapon_damage,0,mob,elite,boss,*qtd_room);

        }
        else if (strcmp(selected_room, room_5.name) == 0)
        {
            fight(player,skill,*weapon_damage,1,mob,elite,boss,*qtd_room);
        }
        else
        {
            clear_screen();
            events(player);
        }
    }
}
//upgrade in one of the player status base_damage or max_hp
void time_chamber(Player *player)
{
    header(6);
    printf("\n\n\t\t\t\t\t\t\t   1 - DamageUp 2 - Max hp Up (Any key - Skip Upgrade)\n\n");
    char ch = getch();

    switch(ch)
    {
    case '1':
        player->base_damage+=10;
        printf("\t\t\t\t\t\t   Base damage increased by 10. New base damage: %d\n", player->base_damage);
        break;
    case '2':
        player->max_hp+=100;
        printf("\t\t\t\t\t\t   Max HP increased by 100. New max HP: %d\n", player->max_hp);
        break;
    default:
        printf("\t\t\t\t\t\t   Skiped upgrade.\n");
        break;
    }
    Sleep(2000);
    clear_screen();
}

//fun��o para curar o jogador na sala de cura
void heal(Player *player)
{
    header(9);
    int heal = player->max_hp/2;
    player->hp += heal;

    if(player ->hp > player->max_hp)
    {
        player-> hp = player-> max_hp;
    }

    printf("\n\n\t\t\tYou have healed %d HP. Current HP: %d\n", heal, player->hp);
    Sleep(1000);

    printf("\nPress any key to continue!");
    getch();

    clear_screen();
}

//fun��o onde ocorrera eventos no qual pode ou n�o ajudar o player
void events(Player *player)
{
    header(13);
    printf("\n\n");
    int event_num = rand() % 5;
    int random_money = rand() % 501;
    switch (event_num)
    {
    case 0:
        printf("You found a secret passage that rewards you with a BIG NOTHING\nand the demons laugh at you behind the walls!");
        break;
    case 1:
        printf("A helpful fairy appears and heals you for 50 HP!");
        player->hp+=50;
        break;
    case 2:
        printf("You trip over a rock and lose 10 HP!");
        player->hp-=10;
        break;
    case 3:
        printf("You find a hidden treasure chest filled with (%d) gold!",random_money);
        player->money += random_money;
        break;
    case 4:
        printf("A sudden trap springs! You barely escape with your life.");
        player->hp = 1;
        player->max_hp = 1;
        printf("Your max health is now: %d",player->max_hp);
        break;
    }
    Sleep(1000);
    printf("\n\nPress any key to continue!");
    getch();

    clear_screen();
}

//fun��o do funcionamento de toda a batalha
void fight(Player* player,Skill*skill,int weapon_damage,int tipo,Monster*mob,Monster*elite,Monster*boss,int qtd_room)
{

    char monster_mob[3][50] = { "Slime", "Goblin", "Skeleton"};
    shuffle(monster_mob,3);
    char monster_elite[3][50] = { "Orc", "Gnoll", "Bear"};
    shuffle(monster_elite,3);
    char monster_boss[3][50] = { "Dragon", "Golem", "Demon"};
    shuffle(monster_boss,3);

    int i;
    bool infight = true;
    bool win = true;
    int monster_damage;
    const number = 20;
    int mob_life = mob->hp;
    int elite_life = elite->hp;
    int boss_life = boss->hp;
    int random_money = rand() % 251;
    bool cooldown_full = true;
    int cooldown_time = 3;
    while(infight)
    {
        clear_screen();
        switch(tipo)
        {
        case 0:
            printf("\t\t\t\t\t\t\t%s\n\n",monster_mob[0]);
            printf("\t\t\t\t\t\t\tHp: %d/%d\n\n",mob->hp,mob->max_hp);
            monster_damage = monster_attack(mob);
            if(strcmp(monster_mob[0],"Slime")== 0)
            {
                sprites(1);
            }
            else
            {
                if(strcmp(monster_mob[0],"Skeleton")== 0)
                {
                    sprites(2);
                }
                else
                {
                    sprites(3);
                }
            }
            break;
        case 1:
            printf("\t\t\t\t\t\t\t%s\n\n",monster_elite[0]);
            printf("\t\t\t\t\t\t\tHp: %d/%d\n\n",elite->hp,elite->max_hp);
            monster_damage = monster_attack(elite);
            if(strcmp(monster_elite[0],"Orc")== 0)
            {
                sprites(5);
            }
            else
            {
                if(strcmp(monster_elite[0],"Gnoll")== 0)
                {
                    sprites(6);
                }
                else
                {
                    sprites(12);
                }
            }
            break;
        default:
            printf("\t\t\t\t\t\t\t%s\n\n",monster_boss[0]);
            printf("\t\t\t\t\t\t\tHp: %d/%d\n\n",boss->hp,boss->max_hp);
            //colocar os sprites dos elite ou algo parecido com
            monster_damage = monster_attack(boss);
            if(strcmp(monster_boss[0],"Dragon")== 0)
            {
                sprites(4);
            }
            else
            {
                if(strcmp(monster_boss[0],"Golem")== 0)
                {
                    sprites(8);
                }
                else
                {
                    sprites(7);
                }
            }
            break;
        }

        printf("\n\n");
        printf("\n\n\tPlayer\n\n");
        printf("Hp: %d/%d\n\n",player->hp,player->max_hp);
        printf("Attack damage: %d/skill damage:%d\n\n",(weapon_damage+player->base_damage),skill->skill_damage);
        if(player -> hp <= 0)
        {
            win = !win;
            break;
        }
        if(mob->hp <= 0 || elite->hp <= 0 || boss->hp <= 0)
        {
            mob->hp = 0;
            elite->hp = 0;
            boss->hp = 0;
            break;
        }
        printf("------------------------------\n");
        printf("|| 1 - Attack | 2 - Skills  ||\n");
        printf("------------------------------\n\n");

        printf("----------------\n");
        printf("|| Battle Log ||\n");
        printf("----------------\n\n");
        char ch =  getch();

        switch(ch)
        {
        case '1':
            ;
            int d20 = rand() % (number + 1);
            int player_damage = player_attack(player,weapon_damage);

            if(d20 > 17)
            {
                printf("Critcal hit! you dealt %d damage",player_damage*2);
                switch(tipo)
                {
                case 0:
                    mob->hp -= player_damage*2;
                    if(mob->hp < 0)
                    {
                        mob->hp = 0;
                    }
                    break;
                case 1:
                    elite->hp -= player_damage*2;
                    if(elite->hp < 0)
                    {
                        elite->hp = 0;
                    }
                    break;
                default:
                    boss->hp -= player_damage*2;
                    if(boss->hp < 0)
                    {
                        boss->hp = 0;
                    }
                    break;
                }
            }
            else
            {
                if(d20>1)
                {
                    printf("You dealt %d damage                                                             ",player_damage);
                    switch(tipo)
                    {
                    case 0:
                        mob->hp -= player_damage;
                        if(mob->hp < 0)
                        {
                            mob->hp = 0;
                        }
                        break;
                    case 1:
                        elite->hp -= player_damage;
                        if(elite->hp < 0)
                        {
                            elite->hp = 0;
                        }
                        break;
                    default:
                        boss->hp -= player_damage;
                        if(boss->hp < 0)
                        {
                            boss->hp = 0;
                        }
                        break;
                    }
                }
                else
                {
                    printf("You missed the attack!!                                                               ");
                }
            }
            break;
        case '2':
            ;
            if(cooldown_full)
            {
                int skill_dmg = use_skill(player,skill);
                printf("You use slash and deal %d damage                                                    ",skill_dmg);
                switch(tipo)
                {
                case 0:
                    mob->hp -= skill_dmg;
                    if(mob->hp < 0)
                    {
                        mob->hp = 0;
                    }
                    break;
                case 1:
                    elite->hp -= skill_dmg;
                    if(elite->hp < 0)
                    {
                        elite->hp = 0;
                    }
                    break;
                default:
                    boss->hp -= skill_dmg;
                    if(boss->hp < 0)
                    {
                        boss->hp = 0;
                    }
                    break;
                }
                cooldown_full = !cooldown_full;
                cooldown_time = 3;
            }
            else
            {
                printf("Skill in cooldown: %d turn(s) left", cooldown_time);
            }

            break;

        }
        printf("\r");
        Sleep(1500);
        //monster damage
        int d20 = rand() % (number + 1);
        if(d20 > 18)
        {
            printf("Critcal hit! you take  %d damage",monster_damage*2);
            player ->hp -= monster_damage*2;
            if(player->hp < 0)
            {
                player->hp = 0;
            }
        }
        else
        {
            if(d20>2)
            {
                printf("You have take %d damage                                       ",monster_damage);
                player ->hp -= monster_damage;
                if(player->hp < 0)
                {
                    player->hp = 0;
                }
            }
            else
            {
                printf("The monster  missed the attack!!             ");
            }
        }
        if (!cooldown_full)
        {
            cooldown_time--;
            if (cooldown_time <= 0)
            {
                cooldown_full = !cooldown_full; // Reset cooldown
            }
        }
        Sleep(1200);
    }
    if(win)
    {

        player -> money += random_money;
        printf("\n\nYou have win the battle!!(adquired %d gold)",random_money);
        printf("\nPress any key to continue!");
        getch();

        mob->hp = mob_life;
        elite->hp = elite_life;
        boss->hp = boss_life;
        clear_screen();
    }
    else
    {
        //gameover
        clear_screen();
        header(7);
        save_record(0,0,player->money,qtd_room);
        Sleep(1500);
        clear_screen();
        menu();
    }
}

void game()
{
    char code;
    //inicia os status do player e monstros
    Player player;
    player.max_hp = 200;
    player.hp = player.max_hp;
    player.base_damage = 10;
    player.money = 250;

    Skill skill;
    skill.skill_damage = 100;

    Monster elite;
    elite.max_hp = 300;
    elite.hp = elite.max_hp;
    elite.base_damage = 20;

    Monster boss;
    boss.max_hp = 500;
    boss.hp = boss.max_hp;
    boss.base_damage = 30;

    Monster mob;
    mob.max_hp = 150;
    mob.hp = mob.max_hp;
    mob.base_damage = 10;

    header(5);
    sprites(9);
    printf("\t\t\t\t\t\t\t   1 - sword\n\n");
    sprites(11);
    printf("\t\t\t\t\t\t\t   2 - scythe\n\n");
    sprites(10);
    printf("\t\t\t\t\t\t\t   3 - katana\n\n");
    char ch = getch();

    int type_weapon = 0;
    switch(ch)
    {
    case '1':
        type_weapon = 30;
        break;
    case '2':
        type_weapon = 45;
        break;
    case '3':
        type_weapon = 50;
        break;
    case '0':
        printf("\n\nEnter with the cheat code:");
        scanf(" %c",&code);

        if(code == 'S')
        {
            type_weapon = 9999;
        }
        break;
    }

    clear_screen();

    int ingame = 1;
    int cont = 0;
    int qtd_room = 0;
    int qtd_boss = 0;
    int qtd_rooms = 0;
    while (ingame)
    {
        header(4);
        printf("\n");
        rooms(cont,&type_weapon,&player,&skill,&mob,&elite,&boss,&qtd_rooms);
        cont++;
        //se boss for derrotado aumentar +10 de dano do player, +20 de dano e 100 de vida dos mobs, +75 nos elite e 100 de vida
        if (cont > 4)
        {
            qtd_room += cont;
            qtd_boss++;
            clear_screen();

            printf("Do you want to end the run here(Y/N)?(PS: you will lose everything you have without forgiveness)\n");
            printf(">>>");
            while ((ch = getchar()) != '\n' && ch != EOF);
            char ch = getchar();
            if(ch == 'Y' || ch == 'y')
            {
              save_record(0,qtd_boss,player.money,qtd_room);
              clear_screen();
              menu();

            }
            clear_screen();
            cont = 0;
            player.base_damage += 10;
            player.max_hp += 100;

            mob.base_damage += 20;
            mob.max_hp += 100;
            mob.hp = mob.max_hp;

            elite.base_damage += 20;
            elite.max_hp += 100;
            elite.hp = elite.max_hp;

            boss.base_damage += 20;
            boss.max_hp += 100;
            boss.hp = boss.max_hp;

        }
        printf("\n");
    }
}

void game_init()
{

    //gera seed para que o numero gerado aleat�riamente nunca seja o mesmo em sequencia
    srand((unsigned int)time(NULL));
    game();
}
