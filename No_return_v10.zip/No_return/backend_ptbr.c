#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <windows.h>
#include <ctype.h>

typedef struct
{
    int max_hp;
    int hp;
    int money;
    int base_damage;
} Jogador;

typedef struct
{
    char name[50];
} Sala;

typedef struct
{
    char name[50];
    int max_hp;
    int hp;
    int base_damage;
} Monstro;

typedef struct
{
    char name[50];
    int skill_damage;
} Habilidade;

// Fun��o para quando o jogador for usar uma habilidade
int usar_habilidade(Jogador* jogador, Habilidade* habilidade)
{
    return habilidade->skill_damage;
}

// Fun��o de ataque do jogador
int ataque_jogador(const Jogador* jogador, int dano_arma)
{
    return jogador->base_damage + dano_arma;
}

// Fun��o de ataque do monstro
int ataque_monstro(const Monstro* monstro)
{
    return monstro->base_damage;
}

// Embaralha as strings
void embaralhar(char arr[][50], int n)
{
    if (n > 1)
    {
        int i;
        for (i = 0; i < n - 1; i++)
        {
            int j = i + rand() / (RAND_MAX / (n - i) + 1);
            char temp[50];
            strcpy(temp, arr[j]);
            strcpy(arr[j], arr[i]);
            strcpy(arr[i], temp);
        }
    }
}

/* Fun��o de compra na loja, onde o jogador s� poder� comprar um item de cada
que est� sendo exibido (em estoque) */
void loja(Jogador* jogador, int* dano_arma, Habilidade* habilidade)
{
    char itens[3][50] = { "Upgrade de Arma", "Upgrade de Habilidade", "Cura (25%)" };
    char ch;
    int i;
    const int numero = 250;
    int precos[3];
    bool em_loja = true;
    bool comprado[3] = { false, false, false };

    for (i = 0; i < 3; i++)
    {
        int preco_aleatorio = rand() % (numero + 1);
        precos[i] = preco_aleatorio;
    }

    while (em_loja)
    {
        header(12);
        printf("\n\n\t\t\t\tDinheiro: %d\n\n", jogador->money);
        printf("\t1 - %s (%d) | 2 - %s (%d) | 3 - %s (%d)\n", itens[0], precos[0], itens[1], precos[1], itens[2], precos[2]);
        printf("\t\t\tPressione qualquer tecla para continuar.\n\n");
        ch = getch();
        int escolha;

        switch (ch)
        {
        case '1':
            escolha = 0;
            break;
        case '2':
            escolha = 1;
            break;
        case '3':
            escolha = 2;
            break;
        default:
            em_loja = !em_loja;
            break;
        }

        if (!em_loja)
        {
            break;
        }

        if (comprado[escolha])
        {
            printf("\nVoce ja comprou %s.\n", itens[escolha]);
            Sleep(1500);
            clear_screen();
            continue;
        }
        if (jogador->money >= precos[escolha])
        {
            jogador->money -= precos[escolha];
            comprado[escolha] = true;
            if (escolha == 0)
            {
                *dano_arma += 20;
                printf("Voce melhorou sua arma e agora causa %d de dano\n", *dano_arma);
            }
            else if (escolha == 1)
            {
                habilidade->skill_damage += 80;
                printf("Voce melhorou sua habilidade e agora causa %d de dano\n", habilidade->skill_damage);
            }
            else
            {
                int cura = (jogador->hp * 0.25);
                jogador->hp += cura;
                if (jogador->hp > jogador->max_hp)
                {
                    jogador->hp = jogador->max_hp;
                }
                printf("Voce curou %d HP. HP atual: %d\n", cura, jogador->hp);
            }
        }
        else
        {
            printf("\nVoce nao tem dinheiro suficiente para comprar %s.\n", itens[escolha]);
        }
        Sleep(2000);
        clear_screen();
    }
}

// Cria e define qual sala o jogador escolheu
void salas(int cont_level, int* dano_arma, Jogador* jogador, Habilidade* habilidade, Monstro* mob, Monstro* elite, Monstro* boss,int *qtd_room)
{
    Sala sala_1 = { "Sala do Tempo" };
    Sala sala_2 = { "Batalha" };
    Sala sala_3 = { "Cura" };
    Sala sala_4 = { "Loja" };
    Sala sala_5 = { "Elite" };
    Sala sala_6 = { "Evento" };
    Sala sala_7 = { "Boss" };

    char ch;
    char salas_array[6][50] = { "Sala do Tempo", "Batalha", "Elite", "Evento", "Batalha", "Batalha" };

    embaralhar(salas_array, 6);

    if (cont_level == 3)
    {
        printf("\t\t\t\t\t\t\t\t1 - %s | 2 - %s\n", sala_3.name, sala_4.name);
        ch = getch();
        switch (ch)
        {
        case '1':
            clear_screen();
            (*qtd_room)++;
            cura(jogador);
            break;
        case '2':
            clear_screen();
            (*qtd_room)++;
            loja(jogador, dano_arma, habilidade);
            break;
        }

        clear_screen();
        header(16);
        printf("Precione qualquer tecla para lutar contra o boss!");
        getch();
    }
    else if (cont_level == 4)
    {
        clear_screen();
        (*qtd_room)++;
        luta(jogador, habilidade, *dano_arma, 2, mob, elite, boss,*qtd_room);
    }
    else
    {
        printf("\t\t\t\t\t\t       1 - %s | 2 - %s | 3 - %s\n", salas_array[0], salas_array[1], salas_array[2]);
        ch = getch();
        clear_screen();
        char* sala_selecionada = NULL;
        if (ch == '1')
        {
            sala_selecionada = salas_array[0];
            (*qtd_room)++;
        }
        else if (ch == '2')
        {
            sala_selecionada = salas_array[1];
            (*qtd_room)++;
        }
        else if (ch == '3')
        {
            sala_selecionada = salas_array[2];
            (*qtd_room)++;
        }
        if (strcmp(sala_selecionada, sala_1.name) == 0)
        {
            clear_screen();
            sala_do_tempo(jogador);
        }
        else if (strcmp(sala_selecionada, sala_2.name) == 0)
        {
            luta(jogador, habilidade, *dano_arma, 0, mob, elite, boss,*qtd_room);
        }
        else if (strcmp(sala_selecionada, sala_5.name) == 0)
        {
            luta(jogador, habilidade, *dano_arma, 1, mob, elite, boss,*qtd_room);
        }
        else
        {
            clear_screen();
            eventos(jogador);
        }
    }
}
// Upgrade em um dos status do jogador: base_damage ou max_hp
void sala_do_tempo(Jogador* jogador)
{
    header(6);
    printf("\n\n\t\t\t\t\t\t\t   1 - Aumento de Dano 2 - Aumento de HP Max (Qualquer tecla - Pular Upgrade)\n\n");
    char ch = getch();
    switch (ch)
    {
    case '1':
        jogador->base_damage += 10;
        printf("\t\t\t\t\t\t   Dano base aumentado em 10. Novo dano base: %d\n", jogador->base_damage);
        break;
    case '2':
        jogador->max_hp += 100;
        printf("\t\t\t\t\t\t   HP Max aumentado em 100. Novo HP Max: %d\n", jogador->max_hp);
        break;
    default:
        printf("\t\t\t\t\t\t   Upgrade pulado.\n");
        break;
    }
    Sleep(2000);
    clear_screen();
}

// Fun��o para curar o jogador na sala de cura
void cura(Jogador* jogador)
{
    header(10);
    int cura = jogador->max_hp / 2;
    jogador->hp += cura;

    if (jogador->hp > jogador->max_hp)
    {
        jogador->hp = jogador->max_hp;
    }

    printf("\n\nVoce curou %d HP. HP atual: %d\n", cura, jogador->hp);
    Sleep(1000);

    printf("\nPressione qualquer tecla para continuar!");
    getch();
    clear_screen();
}

// Fun��o onde ocorrer�o eventos que podem ou n�o ajudar o jogador
void eventos(Jogador* jogador)
{
    header(14);
    printf("\n\n");
    int event_num = rand() % 5;
    int random_money = rand() % 501;
    switch (event_num)
    {
    case 0:
        printf("Voce encontrou uma passagem secreta que recompensa voce com um GRANDE NADA\n e os demonios riem de voce atras das paredes com gosto!");
        break;
    case 1:
        printf("Uma fada prestativa aparece e cura voce em 50 HP!");
        jogador->hp += 50;
        break;
    case 2:
        printf("Voce trope�a em uma pedra e perde 10 HP!");
        jogador->hp -= 10;
        break;
    case 3:
        printf("Voce encontra um bau de tesouro escondido cheio de ouro!");
        jogador->money += random_money;
        break;
    case 4:
        printf("Uma armadilha repentina se ativa! Voce mal escapa com a vida.");
        jogador->hp = 1;
        jogador->max_hp = 1;
        printf("Sua sa�de maxima agora �: %d", jogador->max_hp);
        break;
    }
    Sleep(1000);
    printf("\n\nPressione qualquer tecla para continuar!");
    getch();
    clear_screen();
}



// Fun��o do funcionamento de toda a batalha
void luta(Jogador* jogador, Habilidade* habilidade, int dano_arma, int tipo, Monstro* mob, Monstro* elite, Monstro* boss,int qtd_room)
{
    char monster_mob[3][50] = { "Slime", "Goblin", "Esqueleto" };
    embaralhar(monster_mob, 3);
    char monster_elite[3][50] = { "Orc", "Gnoll", "Urso" };
    embaralhar(monster_elite, 3);
    char monster_boss[3][50] = { "Dragao", "Golem", "Demonio" };
    embaralhar(monster_boss, 3);

    bool infight = true;
    bool win = true;
    int monster_damage;
    const int number = 20;
    int mob_life = mob->hp;
    int elite_life = elite->hp;
    int boss_life = boss->hp;
    int random_money = rand() % 251;
    bool cooldown_full = true;
    int cooldown_time = 3;

    while (infight)
    {
        clear_screen();
        switch (tipo)
        {
        case 0:
            printf("\t\t\t\t\t\t\t%s\n\n", monster_mob[0]);
            printf("\t\t\t\t\t\t\tHp: %d/%d\n\n", mob->hp, mob->max_hp);
            monster_damage = ataque_monstro(mob);
            if(strcmp(monster_mob[0],"Slime")== 0)
            {
                sprites(1);
            }
            else
            {
                if(strcmp(monster_mob[0],"Esqueleto")== 0)
                {
                    sprites(2);
                }
                else
                {
                    sprites(3);
                }
            }
            break;
        case 1:
            printf("\t\t\t\t\t\t\t%s\n\n", monster_elite[0]);
            printf("\t\t\t\t\t\t\tHp: %d/%d\n\n", elite->hp, elite->max_hp);
            monster_damage = ataque_monstro(elite);
            if(strcmp(monster_elite[0],"Orc")== 0)
            {
                sprites(5);
            }
            else
            {
                if(strcmp(monster_elite[0],"Gnoll")== 0)
                {
                    sprites(6);
                }
                else
                {
                    sprites(12);
                }
            }
            break;
        default:
            printf("\t\t\t\t\t\t\t%s\n\n", monster_boss[0]);
            printf("\t\t\t\t\t\t\tHp: %d/%d\n\n", boss->hp, boss->max_hp);
            monster_damage = ataque_monstro(boss);
            if(strcmp(monster_boss[0],"Dragon")== 0)
            {
                sprites(4);
            }
            else
            {
                if(strcmp(monster_boss[0],"Golem")== 0)
                {
                    sprites(8);
                }
                else
                {
                    sprites(7);
                }
            }
            break;
        }

        printf("\n\n");
        printf("\n\n\tJogador\n\n");
        printf("Hp: %d/%d\n\n", jogador->hp, jogador->max_hp);
        printf("Dano do ataque: %d | Dano da Habilidade: %d\n\n", (dano_arma+jogador->base_damage), habilidade->skill_damage);

        if (jogador->hp <= 0)
        {
            win = false;
            break;
        }

        if (mob->hp <= 0 || elite->hp <= 0 || boss->hp <= 0)
        {
            mob->hp = 0;
            elite->hp = 0;
            boss->hp = 0;

            break;
        }
        //passar para frontend
        printf("-----------------------------------\n");
        printf("|| 1 - Atacar | 2 - Habilidades  ||\n");
        printf("-----------------------------------\n\n");

        printf("-------------------------\n");
        printf("|| Registro de Batalha ||\n");
        printf("-------------------------\n\n");
        char ch = getch();
        switch (ch)
        {
        case '1':
        {
            int d20 = rand() % (number + 1);
            int player_damage = ataque_jogador(jogador, dano_arma);

            if (d20 > 17)
            {
                printf("Acerto Critico! Voce causou %d de dano                                          ", player_damage * 2);
                switch (tipo)
                {
                case 0:
                    mob->hp -= player_damage * 2;
                    if(mob->hp < 0)
                    {
                        mob->hp = 0;
                    }
                    break;
                case 1:
                    elite->hp -= player_damage * 2;
                    if(elite->hp < 0)
                    {
                        elite->hp = 0;
                    }
                    break;
                default:
                    boss->hp -= player_damage * 2;
                    if(boss->hp < 0)
                    {
                        boss->hp = 0;
                    }
                    break;
                }
            }
            else
            {
                if (d20 > 1)
                {
                    printf("Voce causou %d de dano                                                       ", player_damage);
                    switch (tipo)
                    {
                    case 0:
                        mob->hp -= player_damage;
                        if(mob->hp < 0)
                        {
                            mob->hp = 0;
                        }
                        break;
                    case 1:
                        elite->hp -= player_damage;
                        if(elite->hp < 0)
                        {
                            elite->hp = 0;
                        }
                        break;
                    default:
                        boss->hp -= player_damage;
                        if(boss->hp < 0)
                        {
                            boss->hp = 0;
                        }
                        break;
                    }
                }
                else
                {
                    printf("Voce errou o ataque!!                                                                      ");
                }
            }
            break;
        }
        case '2':
        {
            if (cooldown_full)
            {
                int skill_dmg = usar_habilidade(jogador, habilidade);
                printf("Voce usou a habilidade e causou %d de dano                                       ", skill_dmg);
                switch (tipo)
                {
                case 0:
                    mob->hp -= skill_dmg;
                    if(mob->hp < 0)
                    {
                        mob->hp = 0;
                    }
                    break;
                case 1:
                    elite->hp -= skill_dmg;
                    if(elite->hp < 0)
                    {
                        elite->hp = 0;
                    }
                    break;
                default:
                    boss->hp -= skill_dmg;
                    if(boss->hp < 0)
                    {
                        boss->hp = 0;
                    }
                    break;
                }
                cooldown_full = false;
                cooldown_time = 3;
            }
            else
            {
                printf("Habilidade em recarga: %d turno(s) restante(s)", cooldown_time);
            }
            break;
        }
        }
        printf("\r");
        Sleep(1500);
        // Dano do monstro
        int d20 = rand() % (number + 1);
        if (d20 > 18)
        {
            printf("Acerto Critico! Voce recebe %d de dano                                       ", monster_damage * 2);
            jogador->hp -= monster_damage * 2;
            if (jogador->hp < 0)
            {
                jogador->hp = 0;
            }
        }
        else
        {
            if (d20 > 2)
            {
                printf("Voce recebeu %d de dano                                       ", monster_damage);
                jogador->hp -= monster_damage;
                if (jogador->hp < 0)
                {
                    jogador->hp = 0;
                }
            }
            else
            {
                printf("O monstro errou o ataque!!                                              ");
            }
        }
        if (!cooldown_full)
        {
            cooldown_time--;
            if (cooldown_time <= 0)
            {
                cooldown_full = !cooldown_full;
            }
        }
        Sleep(1200);
    }

    if (win)
    {
        jogador->money += random_money;
        printf("\n\nVoce venceu a batalha!! (adquirido %d de ouro)\n", random_money);
        printf("Pressione qualquer tecla para continuar!");
        getch();
        mob->hp = mob_life;
        elite->hp = elite_life;
        boss->hp = boss_life;
        clear_screen();
    }
    else
    {
        //gameover
        clear_screen();
        header(8);
        save_record(1,0,jogador->money,qtd_room);
        Sleep(1500);
        clear_screen();
        menu();
    }
}

void jogo()
{
    char code;
    // Inicia os status do jogador e monstros
    Jogador jogador;
    jogador.max_hp = 200;
    jogador.hp = jogador.max_hp;
    jogador.base_damage = 10;
    jogador.money = 250;

    Habilidade habilidade;
    habilidade.skill_damage = 100;

    Monstro elite;
    elite.max_hp = 300;
    elite.hp = elite.max_hp;
    elite.base_damage = 20;

    Monstro boss;
    boss.max_hp = 500;
    boss.hp = boss.max_hp;
    boss.base_damage = 30;

    Monstro mob;
    mob.max_hp = 150;
    mob.hp = mob.max_hp;
    mob.base_damage = 10;

    header(5);

    sprites(9);
    printf("\t\t\t\t\t\t\t   1 - Espada\n\n");
    sprites(11);
    printf("\t\t\t\t\t\t\t   2 - Foice\n\n");
    sprites(10);
    printf("\t\t\t\t\t\t\t   3 - katana\n\n");

    char ch = getch();
    int tipo_arma = 0;
    switch (ch)
    {
    case '1':
        tipo_arma = 30;
        break;
    case '2':
        tipo_arma = 45;
        break;
    case '3':
        tipo_arma = 50;
        break;
    case '0':
        printf("\n\nEntre com o codigo:");
        scanf(" %c",&code);
        if(code == 'S')
        {
            tipo_arma = 9999;
        }
        break;
    }

    clear_screen();

    int em_jogo = 1;
    int cont = 0;
    int qtd_room = 0;
    int qtd_boss = 0;
    int qtd_rooms = 0;
    while (em_jogo)
    {
        header(4);
        printf("\n");
        salas(cont, &tipo_arma, &jogador, &habilidade, &mob, &elite, &boss,&qtd_rooms);
        cont++;
        if (cont > 4)
        {
            qtd_room += cont;
            qtd_boss++;
            clear_screen();
            printf("Deseja encerrar a run aqui(S/N)?(PS: voce perdera tudo o que voce tem sem perdao)\n");
            printf(">>>");
            while ((ch = getchar()) != '\n' && ch != EOF);
            while(getchar() != '\n');
            if(ch == 'S' || ch == 's')
            {
                save_record(1,qtd_boss,jogador.money,qtd_room);
                clear_screen();
                menu();
            }
            clear_screen();
            cont = 0;

            jogador.base_damage += 10;
            jogador.max_hp += 100;

            mob.base_damage += 20;
            mob.max_hp += 100;
            mob.hp = mob.max_hp;

            elite.base_damage += 20;
            elite.max_hp += 100;
            elite.hp = elite.max_hp;

            boss.base_damage += 20;
            boss.max_hp += 100;
        }
    }
}
void inicio_jogo()
{

    //gera seed para que o numero gerado aleat�riamente nunca seja o mesmo em sequencia
    srand((unsigned int)time(NULL));
    jogo();
}
