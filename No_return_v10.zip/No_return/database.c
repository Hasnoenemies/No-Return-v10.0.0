#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#define MAX_SIZE_FILE 100

void lenguage_option(char * lenguage)
{
    FILE *fptr;
    fptr = fopen("Config.txt", "w");
    if (fptr == NULL)
    {
        perror("Error!");
        exit(1);
    }
    fprintf(fptr, "%s\n", lenguage);
    fclose(fptr);
}
int read_config()
{
    FILE *fptr;
    char line[MAX_SIZE_FILE + 3];
    fptr = fopen("Config.txt", "r");
    if (fptr == NULL)
    {
        perror("Error!");
        exit(1);
    }
    while (fgets(line, sizeof(line), fptr) != NULL)
    {
        char stored_leng[50];
        if (sscanf(line, "%49s", stored_leng) == 1)
        {
            char language[50];
            sscanf(line + strlen(stored_leng), "%s", language);
            if (strcmp(language, "English") == 0 || strcmp(language, "Ingles") == 0)
            {
                fclose(fptr);
                return 0;
            }
            sscanf(line + strlen(stored_leng), "%s", language);
            if (strcmp(language, "Portuguese") == 0 || strcmp(language, "Portugues") == 0)
            {
                fclose(fptr);
                return 1;
            }
        }
    }
    fclose(fptr);
}
// 0 - engllish 1 - portuguese
void save_record(int language, int qtd_boss,int qtd_money, int qtd_rooms)
{

    FILE *fptr;
    char line[MAX_SIZE_FILE + 3];
    if(language == 0)
    {
        fptr = fopen("Records.txt", "a");
        if (fptr == NULL)
        {
            perror("Error!");
            exit(1);
        }
        fprintf(fptr, "Total Bosses Defeated: %d\n", qtd_boss);
        fprintf(fptr, "Money: %d\n", qtd_money);
        fprintf(fptr, "Total Rooms Explored: %d\n", qtd_rooms);
        fprintf(fptr, "Date: %s", ctime(&(time_t)
        {
            time(NULL)
        }));
        fprintf(fptr, "-------------------------\n");
        ;

        fclose(fptr);

    }
    else
    {
        fptr = fopen("Historico.txt", "a");
        if (fptr == NULL)
        {
            perror("Error!");
            exit(1);
        }

        fprintf(fptr, "Total de chefes derrotados: %d\n", qtd_boss);
        fprintf(fptr, "Dinheiro: %d\n", qtd_money);
        fprintf(fptr, "Total de salas exploradas: %d\n", qtd_rooms);
        fprintf(fptr, "Data: %s", ctime(&(time_t)
        {
            time(NULL)
        }));
        fprintf(fptr, "-------------------------\n");

        fclose(fptr);
    }

}
// 0 - engllish 1 - portuguese
void read_record(int language)
{
    FILE *fptr;
    int run_count = 1;
    char line[MAX_SIZE_FILE + 3];
    if (language == 0)
    {
        fptr = fopen("Records.txt", "r");
    }
    else
    {
        fptr = fopen("Historico.txt", "r");
    }
    if (fptr == NULL)
    {
        perror("Error opening file");
        exit(1);
    }
    // L� o arquivo linha por linha
    while (fgets(line, sizeof(line), fptr) != NULL)
    {
        if(language == 0)
        {
            if (strstr(line, "Total Bosses Defeated") != NULL)
            {
                printf("\t\tRun %d\n", run_count);
                run_count++;
            }
        }
        else
        {
            if (strstr(line, "Total de chefes derrotados") != NULL)
            {
                printf("\t\tPartida %d\n", run_count);
                run_count++;
            }
        }


        printf("%s", line);
    }
    fclose(fptr);
}
